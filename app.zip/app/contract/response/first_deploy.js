'use strict';

module.exports = {
  // firstDeployResponse:{
  //   result:{
  //     "id": 2,
  //     "folder_info": {
  //       "gitLog": [
  //         "80cb4aa modify at 2021-01-08 18:24",
  //         "6893fc4 modify at 2021-01-08 17:49",
  //         "72d080a modify at 2021-01-08 17:46",
  //         "736d6f9 modify at 2021-01-08 16:46",
  //         "61bca8d modify at 2021-01-08 16:31",
  //         "4c3c3a2 modify at 2021-01-08 15:24",
  //         "2e5a4e6 modify at 2021-01-08 14:49",
  //         "07a89a2 modify at 2021-01-08 10:52",
  //         "537785d modify at 2021-01-08 10:12",
  //         "e069780 modify at 2021-01-07 10:33",
  //         "ab23fb0 modify at 2021-01-07 10:19",
  //         "0f31622 modify at 2021-01-07 10:19",
  //         "04ece98 add README",
  //         ""
  //       ],
  //       "folder": [
  //         "H5dist",
  //         "H5dist 123132",
  //         "zzj-front",
  //         "zzj-front_deploy_bak"
  //       ]
  //     },
  //     "folder_path": "E:\\study\\test",
  //     "now_hash": "80cb4aa",
  //     "git_url": "http://609311490%40qq.com:12345678@120.77.243.114:8899/dist/xfwsy.git",
  //     "git_branch": "fcjd",
  //     "other_info": {
  //       "first_deploy_user": "sxuan",
  //       "git_name": "xfwsy"
  //     },
  //     "updated_at": "2021-01-09T13:27:24.431Z",
  //     "created_at": "2021-01-09T13:27:24.431Z"
  //   }
  // }
};
